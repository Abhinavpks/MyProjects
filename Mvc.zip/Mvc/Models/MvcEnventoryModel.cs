﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace Mvc.Models
{
    public class MvcEnventoryModel
    {
        public int ItemID { get; set; }
        [Required(ErrorMessage = "Please enter Item name")]
        public string ItemName { get; set; }
        [Required(ErrorMessage = "Please enter Item description")]
        public string ItemDescription { get; set; }
        public Nullable<double> Price { get; set; }
        public Nullable<int> StockAvailability { get; set; }

    }
}