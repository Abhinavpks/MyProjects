﻿using Mvc.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Web;
using System.Web.Mvc;

namespace Mvc.Controllers
{
    public class InventoryController : Controller
    {
        // GET: Inventory
        public ActionResult Index()
        {
            IEnumerable<MvcEnventoryModel> inventorylist;
            HttpResponseMessage response = GlobalVariables.httpClient.GetAsync("Inventory").Result;
            inventorylist = response.Content.ReadAsAsync<IEnumerable<MvcEnventoryModel>>().Result;
            return View(inventorylist);
        }

        public ActionResult Modify(int id = 0)
        {
            if (id == 0)
                return View(new MvcEnventoryModel());
            else 
            {
                HttpResponseMessage response = GlobalVariables.httpClient.GetAsync("Inventory/"+ id.ToString()).Result;
                return View(response.Content.ReadAsAsync<MvcEnventoryModel>().Result);
            }
        }

        [HttpPost]
        public ActionResult Modify(MvcEnventoryModel invtry)
        {
            if (invtry.ItemID == 0)
            {
                HttpResponseMessage response = GlobalVariables.httpClient.PostAsJsonAsync("Inventory", invtry).Result;
                TempData["SuccessMessage"] = "New Item inserted Successfuly";
            }
            else 
            {
                HttpResponseMessage response = GlobalVariables.httpClient.PutAsJsonAsync("Inventory/"+invtry.ItemID, invtry).Result;
                TempData["SuccessMessage"] = "Item Updated Successfuly";
            }
            return RedirectToAction("Index");
        }

        public ActionResult Delete(int id)
        {
            HttpResponseMessage response = GlobalVariables.httpClient.DeleteAsync("Inventory/" + id.ToString()).Result;
            TempData["SuccessMessage"] = "Item Deleted Successfuly";
            return RedirectToAction("Index");
        }
    }
}